// The core Firebase JS SDK is always required and must be listed first

// TODO: Add SDKs for Firebase products that you want to use
//firebase.google.com/docs/web/setup#available-libraries -->

// Your web app's Firebase configuration
https: var firebaseConfig = {
  apiKey: "AIzaSyCuOQ09mt6VtRLtFK645W-WYI9vlEYQjWQ",
  authDomain: "e-voting-dbb24.firebaseapp.com",
  projectId: "e-voting-dbb24",
  storageBucket: "e-voting-dbb24.appspot.com",
  messagingSenderId: "440357752678",
  appId: "1:440357752678:web:9b2d7f2c526aca4a4282a7",
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
