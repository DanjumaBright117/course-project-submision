// generate random colors
const setBg = () => {
  const transparency = "1A";
  const randomColor = Math.floor(Math.random() * 16777215)
    .toString(16)
    .padStart(6, "0");
  return "#" + transparency + randomColor;
};

// render graph
function renderGraph(location, { data, labels, backgroundColor, borderColor }) {
  // create graph data
  let lineOptions = {
    scales: {
      yAxes: [{ ticks: { beginAtZero: true } }],
      xAxes: [],
    },
    legend: { display: false },
    elements: { point: { radius: 0 }, line: { tension: 0 } },
    // stepsize: 100,
  };

  // draw graph
  let myChart = new Chart(location, {
    type: "bar",
    data: {
      labels: labels,
      datasets: [
        {
          label: "# of Votes",
          data: data,
          backgroundColor,
          borderColor,
          borderWidth: 1,
        },
      ],
    },
    options: lineOptions,
  });
}
//r return number or return 0
const returnNumberOrZero = (number) => (number ? number : 0);

// util functions
const capitalizeFirstLetter = (word) => word.charAt(0).toUpperCase() + word.slice(1);

// get most frequent
const getMostFrequent = (array) => {
  if (array.length == 0) return "N/A";
  var modeMap = {};
  var maxEl = array[0],
    maxCount = 1;
  for (var i = 0; i < array.length; i++) {
    var el = array[i];
    if (modeMap[el] == null) modeMap[el] = 1;
    else modeMap[el]++;
    if (modeMap[el] > maxCount) {
      maxEl = el;
      maxCount = modeMap[el];
    }
  }
  console.log("Max Element: ", maxEl);
  return maxEl;
};

const logOut = () => {
  if (firebase.auth().currentUser !== null) {
    firebase
      .auth()
      .signOut()
      .then(() => {
        sessionStorage.removeItem("voterAuthUser");
        Swal.fire({ title: "Log Out Successfull", icon: "success", timer: 3000 }).then(
          //redirect to home - dashboard
          () => (window.location.href = `${window.location.protocol}//${window.location.host}`)
        );
      });
  }
};

// html return function
const candidateWrapper = (data) => {
  let div1 = document.createElement("div");
  div1.classList.add("col-lg-3", "col-md-6");

  let div2 = document.createElement("div");
  div2.classList.add("d-flex");

  let div3 = document.createElement("div");
  div3.classList.add("wrapper");

  let h3 = document.createElement("h3");
  h3.classList.add("mb-0", "font-weight-semibold");
  h3.append(capitalizeFirstLetter(data.first_name) + " " + capitalizeFirstLetter(data.last_name));

  let h5 = document.createElement("h5");
  h5.classList.add("mb-0", "font-weight-medium", "text-primary");

  h5.append("Number of Ballots: " + returnNumberOrZero(data.voter_ballots.length));

  let p = document.createElement("p");
  p.classList.add("mb-0", "text-muted");
  p.append("Winning At: " + getMostFrequent(data.voter_constituencies));

  div3.appendChild(h3);
  div3.appendChild(h5);
  div3.appendChild(p);
  div2.appendChild(div3);
  div1.appendChild(div2);

  return div1;

  // let wrapper =
  //   '<div class="col-lg-3 col-md-6">' +
  //   '<div class="d-flex">' +
  //   '<div class="wrapper">' +
  //   '<h3 class="mb-0 font-weight-semibold">' +
  //   capitalizeFirstLetter(data.first_name) +
  //   " " +
  //   capitalizeFirstLetter(data.last_name) +
  //   "</h3>" +
  //   '<h5 class="mb-0 font-weight-medium text-primary">' +
  //   returnNumberOrZero(data.voter_constituencies.length) +
  //   "</h5>" +
  //   '<p class="mb-0 text-muted">' +
  //   returnNumberOrZero(data.voter_ballots.length) +
  //   "</p>" +
  //   "</div>" +
  //   "</div>" +
  //   "</div>";

  // return wrapper;
};

// candidate Item
// create candidate Item 2
const createCandidateItem = (candidate = {}) => {
  let item =
    // '<div class="candidate-container col-lg-4 grid-margin stretch-card">' +
    '<div class="candidate" >' +
    '<div class="profile-img" style="border-radius: 0px" >' +
    '<img src="' +
    candidate.profile_url +
    '" alt="profile.img" />' +
    "</div>" +
    '<p class="profile-name border-bottom">' +
    candidate.name +
    "</p>" +
    '<p class="profile-position"> <strong>ID NO:</strong> ' +
    candidate.id +
    "</p>" +
    '<p class="profile-team">' +
    candidate.bio +
    "</p>" +
    "</div>";
  // +"</div>";
  return item;
};

$((e) => {
  // check if user is logged in and grab details from session Storage
  let authUserString = sessionStorage.getItem("voterAuthUser");
  let authUser = {};
  if (authUserString) {
    authUser = JSON.parse(authUserString);
  }

  if (authUser) {
    // set email
    document.getElementById("auth-user-email-p").innerHTML = authUser.VoterEmail
      ? authUser.VoterEmail
      : "";
    // set Voter Id
    document.getElementById("auth-user-voterid-p").innerHTML = authUser.VoterId
      ? authUser.VoterId
      : "";
  }
});

// Init and Fetch Data from Ballots
$((e) => {
  // create fragment to prevent reflow
  let candidateItem = document.createElement("div");
  candidateItem.classList.add("row");
  // fetch and fill candidates name, votes total color values
  let graphProperties = { labels: [], data: [], backgroundColor: [], borderColor: [] };
  // accumulate total ballots
  let totalVoteCount = 0;
  // Fetch all Ballots from Firestore
  let leadingCandidate = { votecount: 0, name: "", bio: "" };

  //
  let candidateWrapperNode = document.querySelector("#candidate-wrapper");
  let totalVoteCastContainerNode = document.querySelector("#vote-cast-container h4 strong");
  Swal.fire({ title: "Please Wait...", icon: "info" });
  Swal.showLoading();
  firebase
    .firestore()
    .collection("candidates")
    .onSnapshot((results) => {
      // reset data entries
      totalVoteCount = 0; // <-- total vote cast
      candidateItem.innerHTML = "";
      graphProperties = { labels: [], data: [], backgroundColor: [], borderColor: [] };
      candidateWrapperNode.innerHTML = "";
      totalVoteCastContainerNode.innerHTML = "";
      // restructure incoming data
      results.docs.forEach((doc) => {
        // check if is leading candidate
        if (doc.data().voter_ballots.length > leadingCandidate.votecount) {
          leadingCandidate.votecount = doc.data().voter_ballots.length;
          leadingCandidate.name =
            capitalizeFirstLetter(doc.data().first_name) +
            " " +
            capitalizeFirstLetter(doc.data().last_name);
          leadingCandidate.profile_url = doc.data().profile_image;
          leadingCandidate.bio = doc.data().bio;
          leadingCandidate.id = doc.data().id;
          console.log("Leading Candidate: ", leadingCandidate);
        }
        // get total vote count
        totalVoteCount += doc.data().voter_ballots.length;
        // append candidate node item
        candidateItem.appendChild(candidateWrapper(doc.data()));
        // retrieve and append all candidate names
        graphProperties.labels.push(doc.data().first_name + " " + doc.data().last_name);
        // retrieve and append all candidate votes
        graphProperties.data.push(doc.data().voter_ballots.length);
        // create random colors;
        graphProperties.backgroundColor.push(setBg());
        graphProperties.borderColor.push(setBg());
        // display leading candidate
        document.getElementById("leading-candidate").innerHTML =
          createCandidateItem(leadingCandidate);
        // print to console
        console.log("Labels: ", graphProperties.labels);
        console.log("Line Dataset: ", graphProperties.data);
      });
      // find the graph html node element
      let ctx = $("#election-statistics-overview");
      // add candidate vote casts to top bar
      candidateWrapperNode.appendChild(candidateItem);
      // show total vote cast in graph section
      totalVoteCastContainerNode.append(totalVoteCount);
      // show graph
      Swal.fire({ title: "Please Continue", timer: 2000, icon: "success" });
      Swal.hideLoading();
      renderGraph(ctx, graphProperties);
    });
});

$((e) => {
  // Logout User
  $("#log-out-btn").on("click", (e) => {
    if (firebase.auth().currentUser !== null) {
      sessionStorage.removeItem("voterAuthUser");
      firebase
        .auth()
        .signOut()
        .then(() =>
          Swal.fire({ title: "Log Out Successfull", icon: "success", timer: 3000 }).then(
            //redirect to home - dashboard
            () => (window.location.href = `${window.location.protocol}//${window.location.host}`)
          )
        );
    }
  });
});
