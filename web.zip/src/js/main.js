// const { customAlphabet } = require('https://cdn.jsdelivr.net/npm/nanoid/nanoid.js')
// let nanoid = customAlphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 10);

// Login User
$((e) => {
  // Login User
  let fAuth = firebase.auth();
  let fStore = firebase.firestore();
  $("#login-submit").on("click", (e) => {
    e.preventDefault();
    Swal.fire({ title: "Please Wait!...", icon: "info" });
    Swal.showLoading();

    // collect form data
    let cred = {};
    cred.email = $("#form-email").val();
    cred.voter_id = $("#form-voter-id").val();
    cred.password = $("#form-password").val();

    console.log(cred);

    // clear form
    $("#form-email").val("");
    $("#form-voter-id").val("");
    $("#form-password").val("");

    // login with email and password
    fAuth
      .setPersistence(firebase.auth.Auth.Persistence.SESSION)
      .then(() => fAuth.signInWithEmailAndPassword(cred.email, cred.password))
      .then((results) => {
        console.log(results);
        console.log(fAuth.currentUser.uid);
        // locate user with same voter id in firestore
        fStore
          .collection("voters")
          .doc(fAuth.currentUser.uid)
          .get()
          .then((result) => {
            console.log(result.data());
            if (result.data() && result.data().voter_id === cred.voter_id) {
              // login successfull

              let voterAuthUser = {};
              /// store relevant details inside session storage
              // const userKey = Object.keys(window.localStorage).filter((it) =>
              //   it.startsWith("firebase:authUser")
              // )[0];
              // const user = userKey ? JSON.parse(localStorage.getItem(userKey)) : undefined;
              voterAuthUser.UserId = fAuth.currentUser.uid;
              voterAuthUser.VoterId = result.data().voter_id;
              voterAuthUser.VoterConstituency = result.data().constituency;
              voterAuthUser.VoterEmail = result.data().email;
              sessionStorage.setItem("voterAuthUser", JSON.stringify(voterAuthUser));

              /// Notify success message
              Swal.fire({
                icon: "success",
                title: "Login Successuful",
                timer: 5000,
              }).then((result) => {
                /// redirect to dashboard
                if (result.isConfirmed || !Swal.isTimerRunning()) {
                  window.location.href = `${window.location.protocol}//${window.location.host}/pages/dashboard.html`;
                }
              });
            } else {
              Swal.fire({
                title: "Login Failed",
                text: "The User does not appear to Exists",
                icon: "error",
                timer: 2000,
              });
            }
          })
          .catch((error) => {
            // login failed
            fAuth.signOut().then((res) => {
              throw error;
            });
          });
      })
      .catch((error) => {
        if (error.code === "auth/wrongpassword") {
          Swal.fire({
            title: "Login Failed, Invalid Credentials of Voter ID ...",
            icon: "error",
            timer: 2000,
          }).then((results) => {
            // clear form
            $("#form-email").val("");
            $("#form-voter-id").val("");
            $("#form-password").val("");
          });
        } else {
          Swal.fire({ title: "An Error Occurred, Please Try Again", icon: "error", timer: 3000 });
        }
      });
  });
});

// Register User
$((e) => {
  //
  let fAuth = firebase.auth();
  let fStore = firebase.firestore();
  let cred = {};
  let password = "";

  $("#register-submit").on("click", (e) => {
    e.preventDefault();

    cred.email = $("#form-email").val();
    Swal.fire({ title: "Please Wait!...", icon: "info" });
    Swal.showLoading();
    if ($("#form-password").val() === $("#form-confirm-password").val()) {
      password = $("#form-password").val();
    } else {
      Swal.fire({ title: "Mismatched Passwords", icon: "error" });
      Swal.hideLoading();
      return;
    }

    // read user date of birth credential
    cred.dob = $("#form-date").val().split("-").reverse().join("/");
    // read user constituency details
    cred.constituency = $("#form-constituency").val();
    console.log(cred);
    // show loading animation
    // create user with email and password.
    fAuth
      .createUserWithEmailAndPassword(cred.email, password)
      .then((results) => {
        // get uid
        const uid = fAuth.currentUser.uid;
        console.log(uid);
        // push voter object into firebase firestore
        cred.voter_id = getRandomString();
        console.log(cred);
        fStore
          .collection("voters")
          .doc(uid)
          .set(cred)
          .then((result) => {
            console.log("User added to Firestore");
            // show success animation
            Swal.fire({
              title: "Registration Successful",
              html: `Your Voter's ID is <strong>${cred.voter_id}</strong><hr>Please Keep it Safe`,
              icon: "success",
              showConfirmButton: true,
              confirmButtonText: 'Continue <i class="fa fa-arrow-right"></i>',
              confirmButtonColor: "#3bd949",
              allowOutsideClick: false,
            }).then((results) => {
              // clear form
              $("#form-email").val("");
              $("#form-date").val("");
              $("#form-constituency").val("");
              if (results.isConfirmed) {
                // redirect to login page.
                window.location.href = `${window.location.protocol}//${window.location.host}/pages/auth/login.html`;
              }
            });
          })
          .catch((error) => {
            // Notify user of failed login
            console.log(error);
            throw error;
          })
          .finally(() => {
            // ensure user is logged out after failed authentication;
            if (fAuth.currentUser) {
              fAuth.signOut();
            }
          });
      })
      .catch((error) => {
        let errorMessage = "";
        if (error.code === "auth/email-already-exists") {
          errorMessage = "User with Email already login please Consider Logging In";
        } else if (error.code === "already-exists") {
          errorMessage = "Registration Failed,...";
        } else {
          errorMessage = "An Erro Occurred, Please Try Again";
        }
        Swal.fire({ title: errorMessage, icon: "error", timer: 2000 });
      });
    // dismiss success animation
    Swal.hideLoading();
  });
});
