let candidateID;
// capitzlize util functions
var capitalizeFirstLetter = (word) => word.charAt(0).toUpperCase() + word.slice(1);
// cast vote utility function
let castVote = (voterID) => {
  Swal.fire({ title: "Please Wait!...", icon: "info" });
  Swal.showLoading();
  /// compare voter ID with current Logged in user voter id

  let voterAuthUserString = sessionStorage.getItem("voterAuthUser");
  let voterAuthUser = {};
  if (voterAuthUserString) {
    voterAuthUser = JSON.parse(voterAuthUserString);
  }
  console.log(voterAuthUser);

  // get firestore collection references
  let fStoreBallotRef = firebase.firestore().collection("ballots").doc("gtsow2ueXnYV7gWiVnds");
  let fStoreCandidateRef = firebase.firestore().collection("candidates").doc(candidateID);

  // if match send voter id and contituency to ballot box firestore document
  if (voterAuthUser && voterAuthUser.VoterId === voterID) {
    // check if the voter has voted already
    fStoreBallotRef
      .get()
      .then((results) => {
        console.log(results.data());
        if (!(results.data().voters.indexOf(voterAuthUser.VoterId) >= 0)) {
          console.log("You are eligible to vote");
          // continue with voting
          fStoreCandidateRef
            .update({
              voter_ballots: firebase.firestore.FieldValue.arrayUnion(voterAuthUser.VoterId),
              voter_constituencies: firebase.firestore.FieldValue.arrayUnion(
                voterAuthUser.VoterConstituency
              ),
            })
            .then((results) => {
              // if vote cast is successfull
              // push voter id into ballots array
              Swal.hideLoading();
              fStoreBallotRef
                .update({ voters: firebase.firestore.FieldValue.arrayUnion(voterAuthUser.VoterId) })
                .then((results) => {
                  console.log(results);
                  Swal.fire({ title: "Vote Cast Successful", timer: 2000, icon: "success" });
                })
                .catch((error) => {
                  fStoreBallotRef.update({
                    voters: firebase.firestore.FieldValue.arrayRemove(voterAuthUser.VoterId),
                  });
                  Swal.fire({ title: "Internal Server, Error", icon: "error", timer: 2000 });
                });
            })
            .catch((error) => {
              // if vote cast is not successfull
              Swal.fire({ title: "Internal Server, Error", icon: "error", timer: 2000 });
              console.log(error);
              throw error;
            });
        } else {
          // Notify ballot already cast and redirect to results
          Swal.fire({ title: "You have already voted", timer: 2000, icon: "warning" });
          // TODO redirect to login page
        }
      })
      .catch((error) => {
        console.log(error);
        console.log("Internal Server Error, Please Try Again");
      });
  } else {
    // no match
    Swal.fire({
      title: "Please Login Before Casting Vote",
      icon: "warning",
      timer: 3000,
    });
    console.log("Please Login before casting your vote");
    // handle error
  }
};
// Handle Modal Display
let showModal = (e) => {
  // Grab Candidate ID from card
  candidateID = e.target.parentElement.previousSibling.childNodes[2].innerText.split(" ")[2];
  console.log("CANDIDATE ID: " + candidateID);

  // Fire Sweet Alert Modal
  Swal.fire({
    titleText: "Confirm Your Vote Cast",
    input: "text",
    html: 'Enter your voters ID and click <strong>"Continue"</strong> to confirm vote or click <strong>"No Thanks"</strong> to Cancel',
    inputPlaceholder: "Enter your Voter ID",
    confirmButtonText: 'Continue <i class="fa fa-arrow-right"></i>',
    confirmButtonColor: "#3bd949",
    allowOutsideClick: false,
    showCancelButton: true,
    cancelButtonText: "No Thanks",
    cancelButtonColor: "#ff0017",
    inputValidator: (value) => {
      if (!value) {
        return "You need to Enter Your Voters ID";
      } else if (value.length !== 10) {
        return "Invalid Voter ID Entered";
      }
    },
  }).then((results) => {
    if (results.isConfirmed) {
      console.log("RESULTS.VALUE: ", results.value);
      castVote(results.value); // cast Vote
    } else if (results.isDismissed) {
      // dismiss vote modal
      console.log("Vote Has been Dismissed");
    }
  });
};

const logOut = () => {
  if (firebase.auth().currentUser !== null) {
    firebase
      .auth()
      .signOut()
      .then(() => {
        sessionStorage.removeItem("voterAuthUser");
        Swal.fire({ title: "Log Out Successfull", icon: "success", timer: 3000 }).then(
          //redirect to home - dashboard
          () => (window.location.href = `${window.location.protocol}//${window.location.host}`)
        );
      });
  }
};

// check if user is logged in and grab details from session Storage
$((e) => {
  let authUserString = sessionStorage.getItem("voterAuthUser");
  let authUser = {};
  if (authUserString) {
    authUser = JSON.parse(authUserString);
  }

  if (authUser) {
    // set email
    document.getElementById("auth-user-email-p").innerHTML = authUser.VoterEmail
      ? authUser.VoterEmail
      : "";
    // set Voter Id
    document.getElementById("auth-user-voterid-p").innerHTML = authUser.VoterId
      ? authUser.VoterId
      : "";
  }
});

// Get all Candidates
$((e) => {
  // create candidate Item
  let createCandidateItem2 = (candidate = {}) => {
    // Candidate Vote Button
    let candidateContainerDiv = document.createElement("div");
    candidateContainerDiv.classList.add(
      "candidate-container",
      "col-lg-4",
      "grid-margin",
      "stretch-card"
    );

    let candidateDiv = document.createElement("div");
    candidateDiv.classList.add("candidate");

    let imageDiv = document.createElement("div");
    imageDiv.classList.add("profile-img");

    let img = document.createElement("img");
    img.src = candidate.profile_image;
    img.alt = "profile-image";

    let pName = document.createElement("p");
    pName.classList.add("profile-name", "border-bottom");
    pName.append(
      capitalizeFirstLetter(candidate.first_name) + " " + capitalizeFirstLetter(candidate.last_name)
    );

    let pPosition = document.createElement("p");
    pPosition.classList.add("profile-position");
    let strong = document.createElement("strong");
    strong.append("ID NO: " + candidate.id);
    pPosition.appendChild(strong);

    let pTeam = document.createElement("p");
    pTeam.classList.add("profile-team");

    imageDiv.appendChild(img);
    candidateDiv.appendChild(imageDiv);
    candidateDiv.appendChild(pName);
    candidateDiv.appendChild(pPosition);
    candidateDiv.appendChild(pTeam);

    // Candidate Voter Button
    let voteDialogDiv = document.createElement("div");
    voteDialogDiv.classList.add("vote-dialog");

    let div = document.createElement("div");

    let voteDialogImg = document.createElement("img");
    voteDialogImg.src = "../img/finger_print.png";
    voteDialogImg.alt = "finger-print";

    let voteDialogButton = document.createElement("div");
    voteDialogButton.classList.add("text");
    voteDialogButton.append("VOTE");
    voteDialogButton.id = "vote-button";
    voteDialogButton.addEventListener("click", showModal);

    div.appendChild(voteDialogImg);
    voteDialogDiv.appendChild(div);
    voteDialogDiv.appendChild(voteDialogButton);

    // append both elements
    candidateContainerDiv.appendChild(candidateDiv);
    candidateContainerDiv.appendChild(voteDialogDiv);

    return candidateContainerDiv;
  };

  // create candidate Item 2
  let createCandidateItem = (candidate = {}) => {
    let item =
      '<div class="candidate-container col-lg-4 grid-margin stretch-card">' +
      '<div class="candidate">' +
      '<div class="profile-img">' +
      '<img src="' +
      candidate.profile_image +
      '" alt="profile.img" />' +
      "</div>" +
      '<p class="profile-name border-bottom">' +
      candidate.first_name[0].toUpperCase() +
      candidate.first_name.substr(1) +
      " " +
      candidate.last_name[0].toUpperCase() +
      candidate.last_name.substr(1) +
      "</p>" +
      '<p class="profile-position"> <strong>ID NO:</strong> ' +
      candidate.id +
      "</p>" +
      '<p class="profile-team">' +
      candidate.bio +
      "</p>" +
      "</div>" +
      '<div class="vote-dialog">' +
      "<div>" +
      '<img src="../img/finger_print.png" alt="finger-print" />' +
      "</div>" +
      '<div onclick="showModal(event)" id="vote-button" class="text">VOTE</div>' +
      "</div>" +
      "</div>";
    return item;
  };

  let fStore = firebase.firestore();
  let candidateReference = fStore.collection("candidates");
  // let location = document.getElementById("candidates-list");
  let location = document.createElement("div");
  location.classList.add("row");
  location.id = "candidates-list";

  Swal.fire({ title: "Please Wait!...", icon: "info" });
  Swal.showLoading();
  candidateReference
    .get()
    .then((results) => {
      // do something with the date
      let candidatesList = [];
      results.docs.forEach((doc) => {
        candidatesList.push(doc.data());
        // display candidates
        // location.appendChild(createCandidateItem2(doc.data()));
        location.innerHTML += createCandidateItem(doc.data());
      });
      // console.log(candidatesList);
      document.getElementById("candidates-list-wrapper").append(location);
      Swal.fire({ title: "Please Continue", timer: 2000, icon: "info" });
      Swal.hideLoading();
    })
    .catch((error) => {
      // handle errors
      console.log(error);
    });
});

// Logout User
$("#log-out-btn").on("click", (e) => {
  logOut();
});
