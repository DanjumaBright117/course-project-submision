function openFile() {
  // open file dialog
  let fileInput = document.getElementById("file-input");
  fileInput.click();

  // get file path
  // let filePath = fileInput.files[0].path;
  // console.log('File Path: ', filePath);
}

function redirectToDashboard() {
  window.location.href = `${window.location.protocol}//${window.location.host}/pages/dashboard.html`;
}

$((e) => {
  "use strict";

  let fStorage = firebase.storage().ref();
  let fStore = firebase.firestore();
  let fAuth = firebase.auth();

  // check admin auth login
  let fAuthAdmin = sessionStorage.getItem("fAuthAdmin");
  fAuthAdmin = JSON.parse(fAuthAdmin);

  if (fAuthAdmin == null) {
    Swal.fire({
      title: "Authentication Error",
      text: "admin privilege is required to proceed",
      icon: "error",
      confirmButtonText: "Login",
      confirmButtonColor: "green",
      showCancelButton: true,
      allowOutsideClick: false,
      allowEscapeKey: false,
      cancelButtonText: 'Go Back <i class="fa fa-arrow-left"></i>',
      cancelButtonColor: "red",
    }).then((results) => {
      if (results.isConfirmed) {
        // show admin auth dialog
        Swal.fire({
          title: "Admin Login",
          html:
            '<div class="input-group mb-3 input-group">' +
            '<input id="swal-input1" placeholder="Enter your E-Mail" type="email" class="form-control input-group p-3">' +
            "</div>" +
            '<div class="input-group mb-3 input-group">' +
            '<input id="swal-input2" placeholder="Enter your Password" type="password" class="form-control input-group p-3">' +
            "</div>",
          focusConfirm: false,
          preConfirm: () => {
            return [
              document.getElementById("swal-input1").value,
              document.getElementById("swal-input2").value,
            ];
          },
          allowEscapeKey: false,
          allowOutsideClick: false,
          confirmButtonColor: "#3bd949",
          showCancelButton: true,
          cancelButtonColor: "#ff0017",
        }).then((results) => {
          if (results.isConfirmed) {
            // handle admin authentication
            Swal.fire({
              title: "Please Wait!,...",
              icon: "info",
              allowEscapeKey: false,
              allowOutsideClick: false,
            });
            Swal.showLoading();
            console.log(results.value);
            fAuth
              .signInWithEmailAndPassword(results.value[0], results.value[1])
              .then((results) => {
                // Notifiy Success
                console.log(results);
                // construct adminUser object and stringify to sessionStorage
                let fAuthAdmin = {};
                fAuthAdmin.uid = results.user.uid;
                fAuthAdmin.email = results.user.email;
                sessionStorage.setItem("fAuthAdmin", JSON.stringify(fAuthAdmin));
                Swal.fire({ title: "Admin Sign In Successful", icon: "success", timer: 3000 });
              })
              .catch((error) => {
                // Notify Error Logging In
                Swal.fire({ title: "Admin Sign In Failed", icon: "error", timer: 3000 });
                console.log(error);
              });
            Swal.hideLoading();
            // redirectToDashboard();
          } else if (results.isDismissed) {
            // redirect to index;
            redirectToDashboard();
          }
        });
      } else if (results.isDismissed) {
        // go back to index
        redirectToDashboard();
      } else {
        return;
      }
    });
  } else if (fAuthAdmin.uid && fAuthAdmin.email) {
    // Notify already logged in
    Swal.fire({ title: "Admin Already Logged In", timer: 2000, icon: "success" });
  }

  // Add Candidate to Db
  let fileInput = document.getElementById("file-input");
  let file, fileUrl;

  let candidate = {
    first_name: "",
    last_name: "",
    email: "",
    bio: "",
    id: "",
    voter_ballots: [],
    voter_constituencies: [],
    profile_image: "",
  };

  $("#form-submit").on("click", (e) => {
    e.preventDefault();
    /* collect candidate details */
    Swal.fire({
      title: "Uploading Data...",
      icon: "info",
      allowEscapeKey: false,
      allowOutsideClick: false,
      showConfirmButton: false,
    });

    candidate.first_name = $("#candidate-first-name").val();
    candidate.last_name = $("#candidate-last-name").val();
    candidate.email = $("#candidate-email").val();
    candidate.bio = $("#candidate-bio").val();
    candidate.id = getRandomString(15);
    candidate.voter_ballots = [];
    candidate.voter_constituencies = [];
    candidate.profile_image = "";

    console.log(candidate);

    file = fileInput.files[0];
    // console.log(file);
    /* // form storage bucker url */
    if (
      candidate.first_name &&
      candidate.last_name &&
      candidate.email &&
      candidate.bio &&
      candidate.id
    ) {
      let storageUrl = `candidates/${candidate.id}/profile_image${candidate.id}.${
        file.type.split("/")[1]
      }`;

      let fStorageRef = fStorage.child(storageUrl);

      fStorageRef
        .put(file)
        .then(async (results) => {
          // and add image public url to candidate obj
          candidate.profile_image = await fStorageRef.getDownloadURL();

          // push candidate obj to firestore
          console.log(candidate);

          fStore
            .collection("candidates")
            .doc(candidate.id)
            .set(candidate)
            .then((results) => {
              Swal.fire({
                title: "Candidate Registration Succesful,..",
                timer: 2000,
                icon: "success",
              });
            })
            .catch((error) => {
              // remove canidate image from firestore cloud storage
              fStorageRef
                .delete()
                .then((results) => {
                  console.log(results);
                })
                .catch((error) => {
                  console.log(error);
                });
              throw error;
            });
        })
        .catch((error) => {
          // Notifiy user of failed candidate registration
          Swal.fire({ title: "Error Uploading Candidate,...", timer: 3000, icon: "error" });
          console.log(error);
        });

      //
      Swal.hideLoading();

      // clear form
      $("#candidate-first-name").val("");
      $("#candidate-last-name").val("");
      $("#candidate-email").val("");
      $("#candidate-bio").val("");
    } else {
      Swal.fire({ title: "Please Fill out the Form Completely", icon: "warning", timer: 2000 });
    }
    // // reset the candidate obj
    // candidate = {};
  });

  $("#form-clear").on("click", (e) => {
    // clear form
    $("#candidate-first-name").val("");
    $("#candidate-last-name").val("");
    $("#candidate-email").val("");
    $("#candidate-bio").val("");
  });
});
